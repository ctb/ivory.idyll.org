CREATE TABLE table_under_test (
    x INTEGER,
    y INTEGER
);
