"""
Database setup & teardown.
"""
from subprocess import Popen, PIPE

import psycopg

def create_db():
    """
    Drop and then re-create the test database.
    """
    cmd = Popen("psql", stdin=PIPE, stdout=PIPE, stderr=PIPE)

    (stdout, stderr) = cmd.communicate('''\
CREATE DATABASE "titus-tut";
\c titus-tut
\i ../table.sql
\q
''')

    returncode = cmd.returncode

    print 'STDOUT:', stdout
    print 'STDERR:', stderr

    if returncode != 0:
        print "Please make sure that you have a default database created for this user, and that the user has the ability to create & drop new databases."
        
    assert returncode == 0, "cannot create database: %d" % (returncode,)

def init_db_values(conn):
    c = conn.cursor()

    for (x, y) in ((5, 10), (6, 11), (7, 25)):
        c.execute('INSERT INTO table_under_test (x, y) VALUES (%d, %d)', (x,y))

    conn.commit()

def delete_db():
    """
    Drop the test database.
    """
    dbname = 'titus-tut'

    cmd = Popen("psql", stdin=PIPE, stdout=PIPE, stderr=PIPE)

    (stdout, stderr) = cmd.communicate('DROP DATABASE "titus-tut";\n\q')
    assert cmd.returncode == 0
