import psycopg
import utils

conn = None

def setup():
    utils.create_db()
    
    global conn
    conn = psycopg.connect('dbname=titus-tut')
    utils.init_db_values(conn)

def teardown():
    global conn
    del conn
    
    utils.delete_db()

###

def test():
    """
    Check to make sure that (5, 10) is in the table.
    """
    c = conn.cursor()
    c.execute('SELECT y FROM table_under_test WHERE x=5')
    
    vals = c.fetchall()
    assert len(vals) == 1
    y = vals[0][0]

    assert y == 10
