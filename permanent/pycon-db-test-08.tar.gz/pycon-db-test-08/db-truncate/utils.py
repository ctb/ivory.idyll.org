"""
Database setup & teardown.
"""

import psycopg

def create_db():
    """
    Truncate the tables in the database.
    """
    conn = psycopg.connect('dbname=titus-tut')
    c = conn.cursor()

    c.execute('TRUNCATE TABLE table_under_test')
    conn.commit()

def init_db_values(conn):
    c = conn.cursor()

    for (x, y) in ((5, 10), (6, 11), (7, 25)):
        c.execute('INSERT INTO table_under_test (x, y) VALUES (%d, %d)', (x,y))

    conn.commit()

def delete_db():
    """
    Do nothing here; the setup takes care of cleaning up the databases.
    """
