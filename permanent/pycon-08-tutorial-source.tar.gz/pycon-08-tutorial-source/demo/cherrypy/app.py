#! /usr/bin/env python
import cherrypy

class HelloWorld(object):
    def index(self):
        return """<form method='POST' action='/form'>
                  Type something: <input type='text' name='inp'>
                  <input type='submit'>
                  </form> <a href='./page2'>(another page)</a>"""
    index.exposed = True

    def form(self, inp=None, **kw):
        return "You typed: \"%s\"" % (inp,)
    form.exposed = True

    def page2(self):
        return "This is page2."
    page2.exposed = True

    def exit(self):
        raise SystemExit
    exit.exposed = True

if __name__ == '__main__':
    cherrypy.quickstart(HelloWorld())
