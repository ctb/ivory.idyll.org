import time, httplib, twill
from subprocess import PIPE, STDOUT, Popen
from twill.commands import *

url = pipe = None

def setup():
    global url, pipe
    
    # start server
    pipe = Popen("./app.py", shell=True, stdout=PIPE, stderr=STDOUT)

    # wait for it to actually start up
    time.sleep(1)
    url = "http://localhost:8080/"

def test():
    twill.execute_file('simple-test.twill', initial_url=url)
    
def teardown(module):
    # kill server
    try:
        go(url + "exit")
    except httplib.BadStatusLine:
        pass
    pipe.wait()
