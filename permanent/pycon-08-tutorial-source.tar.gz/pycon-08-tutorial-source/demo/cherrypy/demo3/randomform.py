import twill
import random
from _mechanize_dist import ClientForm
from twill.utils import set_form_control_value
from twill.errors import TwillAssertionError

__all__ = ['fuzzfill']

alphabets = {
    'alpha' : 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
    'alphanum' : 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ' + \
        '0123456789'
    }

def _build_value(alphabet, min_len, max_len):
    take_from = alphabets[alphabet]
    
    value = [ random.choice(take_from) for i in range(min_len, max_len) ]
    value = "".join(value)
    
    return value

def fuzzfill(formname, min_len, max_len, alphabet='alpha'):
    min_len = int(min_len)
    max_len = int(max_len)
    
    browser = twill.get_browser()
    form = browser.get_form(formname)
    if not form:
        raise TwillAssertionError("no matching forms!")

    for widget in form.controls:
        if isinstance(widget, ClientForm.TextControl) and not widget.readonly:
            value = _build_value(alphabet, min_len, max_len)

            print 'fuzzfill: widget \"%s\" using value \"%s\"' % (widget.name,
                                                                  value)

            set_form_control_value(widget, value)
            browser.clicked(form, widget)
