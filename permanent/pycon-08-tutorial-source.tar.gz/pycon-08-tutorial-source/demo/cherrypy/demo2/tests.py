import app

import sys
import cherrypy
import twill
from cStringIO import StringIO

def setup():
    wsgi_app = cherrypy.tree.mount(app.HelloWorld(), '/')

    ###
    twill.add_wsgi_intercept('localhost', 80, lambda: wsgi_app)
    ###
    
    x, sys.stderr = sys.stderr, StringIO()
    try:
        cherrypy.engine.start(blocking=False)
    finally:
        sys.stderr = x

def test():
    twill.execute_file('simple-test.twill', initial_url='http://localhost/')
    
def teardown(module):
    twill.remove_wsgi_intercept('localhost', 80)
    cherrypy.engine.stop()
